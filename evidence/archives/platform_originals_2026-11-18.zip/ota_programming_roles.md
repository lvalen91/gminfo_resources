# OTA & Module Programming Roles — Who Reflashes What (gminfo37 / A11)

Companion to [`ota_update_stack.md`](ota_update_stack.md) (the on-radio OTA engine) and
[`firmware_versions.md`](firmware_versions.md). Question: **GM OTA pushed to the radio can include
calibration of other modules — does a component of the A11 perform SPS/DPS-style programming
itself, or hand off to something that can?**

Sources: [`../research/UPDATE_PROCESS_ANALYSIS.txt`](../research/UPDATE_PROCESS_ANALYSIS.txt),
[`../research/VIP_CONTROL_ANALYSIS.txt`](../research/VIP_CONTROL_ANALYSIS.txt),
[`../research/GM_REMOTE_ACCESS_ANALYSIS.txt`](../research/GM_REMOTE_ACCESS_ANALYSIS.txt),
[`../research/GM_INFO37_BOOT_CHAIN_ANALYSIS.md`](../research/GM_INFO37_BOOT_CHAIN_ANALYSIS.md); the
GIS-646 CalDef database ([`../reference/`](../reference/)); the DPS logs
([`../diagnostics/dps/`](../diagnostics/dps/)); the archived Y181 update package.

## Answer (reconciled)

**Both roles exist, split by target and by architecture generation:**

1. The A11 **is** a programming coordinator — GM's CalDefs cast the infotainment as the
   **Programming Master** (Global A) / **self-programming** module (Global B), and it runs the UDS
   SecurityAccess unlock. It performs SPS/DPS-style operations for **its own domain**.
2. The A11 flashes **its own sub-modules itself**: `gm_update_engine → IPC → VIP MCU (RH850) →
   UDS/CAN`. Well-attested.
3. **Telematics/CGM is the cellular download conduit** (Cloud → CGM → `gmConnectionService` →
   `gm_update_engine`) + an independent direct-CAN command path — **not**, on the evidence here,
   the module flasher.
4. Cross-module reflash of *foreign* ECUs is **defined** in the CalDefs (Programming Master / RRM
   addressing the central gateway `0x45`) but **not captured** in any log here — the only reflash
   traffic documented is radio-domain modules via the VIP.

> **Correction to an earlier hypothesis:** cross-module reflash is *not* shown to be "handed off
> to the Bosch CGM." CAN gateway `0x45` **is** the CGM (Central Gateway Module) — the GIS763 CalDef
> records `GIS763_Gateway = 69 (0x45)` = "Diagnostic Address of the CGM" (below) and the DPS scan
> confirms `0x45` as the diagnostic gateway. What is *not* established is that this CGM (as opposed
> to the radio's VIP MCU) *executes* foreign-ECU reflash: every file that names the programmer names
> the **radio's VIP MCU**; telematics/CGM appears only as transport + an independent command path.
> Keep "CGM executes reflash" as an unverified hypothesis pending a live multi-module OTA capture.

## What GM actually pushes — the Y181 package

The last major release, **Y181** (`W231E-Y181.3.2-SIHM22B-499.3`, USB full package `86334732`),
is a 15-part bundle (15 rows in the archived `delivery_manifest.csv`; corrected 2026-11-12 from "18-part" — 18 is the radio's installed-module inventory, see note below the table; `research/UPDATE_PROCESS_ANALYSIS.txt:237`) — **all parts are CSM/radio-domain**, none are foreign vehicle ECUs
(from the archived `delivery_manifest.csv`; cross-ref [`firmware_versions.md`](firmware_versions.md)):

| Module ID | Part # | Image | Sign |
|---:|---|---|---|
| 1 | 86331656 | VIP_APP (RH850 app fw) | **TSS** |
| 21 | 85098662 | SOC_HOSTOS (GHS INTEGRITY) | **TSS** |
| 22 | 86331654 | SOC_SYSTEM (Android /system) | **TSS** |
| 23 | 86331652 | SOC_BOOT | NONE |
| 24 | 86331623 | SOC_UTILS | NONE |
| 26 | 86331650 | SOC_VENDOR (/vendor) | **TSS** |
| 28 | 85843750 | SXM | NONE |
| 29 | 85121980 | GPS | NONE |
| 51 | 85155539 | TUNER | NONE |
| 52 | 85759612 | ETH_SWITCH (switch cfg; Marvell 88Q5050 on this unit — see note below) | NONE |
| 55 | 86331630 | SOC_ACPIO | NONE |
| 56 | 86331644 | SOC_VBMETA (AVB) | NONE |
| 57 | 86331636 | SOC_PRODUCT (/product) | NONE |
| 71 | 85056831 | VIP_BOOT | NONE |
| 72 | 85738845 | SOC_ABL (Intel bootloader) | NONE |

### SXM stock-file CAN attempt — 2026-11-17

**Result: no SXM firmware write.** A direct-CAN attempt against the current
VIP application reached RequestDownload but was rejected on the first
TransferData block. This establishes rejection on the tested application-mode
calibration route, not impossibility through a different bootloader or internal
update route.

Fresh F182 identified SXM module1C as part84999468/DLSAC; all14 LTZ calibration
identities matched the pinned stock set and baseline PEC was0000. The matching
Y175 USB file is824608 bytes, SHA-256
`d9d30c1de45fae2beb66418c9bef74788770171d69357d40f4d3cf1f5873c094`.
The file starts with zero bytes rather than a0301 calibration header. Moria
found no recognized structure or extractable payload; its entropy observation
alone does not establish encryption.

The test retained the32-frame CAN harness at500kbit/s, used testerF1,
extended session and granted security profile01, then received positive FF01,
021E,8502,280301 and1002 responses. No verifier-marker RAM writes were made.

| Test | RequestDownload | First1022 file bytes in36 01 | Immediate F0F1 |
|---|---|---|---|
| Exact unmodified SXM OTA file; declared824608 bytes | `34 00 44 00000000 000C9520` → `74 20 0F FF` | `7F 36 72` | `000A` |
| Separate target-gate probe:1457-byte stock slot0C container with only header module ID changed000C→001C | `34 00 44 00000000 000005B1` → `74 20 0F FF` | `7F 36 72` | `000F` |

The second input was a diagnostic gate probe, **not an SXM firmware container**.
Neither test sent further blocks or TransferExit after rejection. A positive34
response therefore did not establish acceptance of the file type or target.

Static correlation in VIP_APP85759599 (RH850, Ghidra image base0; SHA-256
`d729fa4b59095b03b05ee26e09e3eb31dda36678055f77be11f24416dd1ad239`):
file56D2C requires the0301 header and sets PEC000A otherwise. File56CCA accepts
only module IDs02–0F and sets PEC000F otherwise. These gates are called by
56D50 before signature validation; first-block handler4F174 returns NRC72 when
that parser fails, before its payload-processing call8615C. File offsets are
not runtime addresses (runtime = file +27A7A for this image).

Cleanup rewrote the unchanged, pinned stock slot0C: `76 01`, `76 02`, `77`.
F182 remained byte-identical. An immediate post-restart status read timed out;
settled reads then confirmed all14 F0F0 statuses00 and F0F1/F0F2 both0000.
Immediate cleanup returned `7F 10 22`, `7F 28 7F`, `7F 85 7F`; later1003 and8501
succeeded,280001 returned `7F 28 22`, and1001 succeeded. Do not describe
communication re-enable as positively acknowledged. Full harness replay remains
active. No power cycle or SXM audio-function test was performed in this attempt.

Separate mounted-image evidence: Y175 `libpal_swupdate_sxm.so`, SHA-256
`c4a0d8568154ac2f4b2471fb68e213b330d1fe63231f75143ed4961eca8facbf`,
is x86-64 ELF. Export `swu_update_sxm` at virtual addressE4C30 consists of
`mov eax,0xB; ret`; it performs no write through that export. The meaning of
return code0B and any alternate SXM update implementation remain unresolved.
This is static image evidence, not a live call of that export.

**Full-USB follow-up:** the normal Y175 package later completed successfully
with CAN-supplied RUN and the USB battery-ignore marker. Android changed
slotB→A; stored update status1/99%/error0 and clean CAN calibration status were
verified after the final mute-hold restart. The recovery script scheduled
SXM28/84999468, but the per-module log was not readable; rewriting versus
same-version skipping is unresolved. This is not a T1/CAN-only or SXM-only
write. See the [owning full-update observation](ota_update_stack.md#y175-full-usb-update-bench-observation--2026-11-17).

### Measured package component sizes (2026-11-17)

Read-only file-size checks of the local Y175 and Y181B `USB_Files` packages:

| Component / module ID (hex) | Y175 part / file bytes | Y181B part / file bytes |
|---|---|---|
| SOC_VBMETA / 38 | 85759606 / 1,688 | 86331644 / 1,693 |
| SOC_ACPIO / 37 | 85759610 / 2,852 | 86331630 / 2,850 |
| TUNER / 33 | 85155539 / 673,191 | 85155539 / 673,191 |
| SXM / 1C | 84999468 / 824,608 | 86404694 / 2,237,910 |
| GPS / 1D | 85121980 / 936,516 | 85121980 / 936,516 |
| ETH_SWITCH / 34 | 85759612 / 1,497,632 | 85759612 / 1,497,632 |

These are packaged file sizes, not decoded payload sizes, flash allocations,
or established CAN transfer lengths. SXM is modest relative to Android images,
but distinct from the roughly 1.5 KB slot0C feature-calibration container.
Small size does not establish suitability for an isolated write: VBMeta belongs
to verified boot, and the update route for peripheral firmware must be traced.
No firmware-component write was attempted by this size check. CAN calibration
acceptance does not establish that module1C uses the same programming path.

> **Corrected 2026-11-12 against the live Y181B radio's on-radio module inventory**
> (`update_cache/update/moduleinfo` pulled from `/cache`, timestamp field written 2026-11-12 13:10 AKST; directly read):
> - Module 52 reports `MVL88Q5050_globalB_234702AB_02_09_1003` (part 85759612, DLS AA) = **Marvell 88Q5050**, not
>   BCM89551. The switch IC is board-variant (BCM89551 on MY22/DV boards, 88Q5050 on MY23+; see
>   [`networking.md`](networking.md)); the part number is the same, so the former "BCM89551 cfg" label was a
>   teardown-unit assumption. Module identity here is the updater's report, not a chip read; live `init.svc.ethmvlctrlmgr=running` / `ethctrlmgr=stopped` (adb) agrees (inferred).
> - The radio inventories **18 modules**, this table lists 15. Not in the table: 53 `SOC_ANDROID_ODM` (part 0,
>   DLS AA), 54 `SOC_ANDROID_ACPI` (part 0, AA), 81 `FIDM` (84961617, AA, version `6`). Whether those three ship as
>   separate package parts or ride inside others is **not established**.
> - Naming: the radio calls module 72 (85738845, DLS AB, version `2344`) `SOC_BOOT` and module 23 (86331652)
>   `SOC_ANDROID_BOOT`; module 24 is `SOC_ANDROID_BOOTLOADER_UTILS`. This table's `SOC_BOOT`/`SOC_ABL`/`SOC_UTILS`
>   labels are the package-side names.
> - Modules 28/29/51 are listed above with the USB package's part numbers (85843750 / 85121980 / 85155539). The
>   radio currently reports `TUNER_XM` 86404694 (DLS AC), `GPS` part 0, `TUNER_DIGITAL` part 0 (DLS AA each).
>   The installed set therefore differs from this package for those three; unreconciled.
> - Installed versions: VIP_BOOT (71) 85056831 DLS AA `B2.9C.01.01` (build 23Jul28-1212, image `bolo`);
>   VIP_APP (1) 86331656 DLS CN `2B.B5.01.01` (build 25Jun19-2209); SOC_HOSTOS (21) 85098662 DLS BM
>   `INTEGRITY IoT 2020.18.19 MY22-026`.

Every row: `Release Type = DEV_REL`, **`Bypass P/N & Module ID Check = TRUE`**, `CVN = EMPTY`,
`Fill/Pad = 0xFF`, signing issuer `CN=GPD, OU=GMNA GPD PRODUCTION, O=GENERAL MOTORS LLC`.
`Vit2File.vit` = ordered USB flash descriptor; `gm_usb_ignore_battery` skips the battery check.
**Y181 vs Y177:** the whole SoC/Android side + VIP_APP were re-spun (VIP_APP rev CM→CN); HostOS,
VIP_BOOT, ABL, tuner/GPS/SXM/eth-switch are byte-identical part numbers.

So "OTA that includes calibration of other modules" here = **the radio's own multi-processor
stack** (Intel SoC + Android partitions + Renesas VIP + tuner/GPS/SXM/eth-switch) — a whole-ECU
bundle the radio installs into itself. Genuinely foreign-ECU calibrations ship as separate GM
packages, not in this bundle.

## The programming machinery on the radio

```
GM Cloud (vtmpub.oboservices.mobi)                     ── or ──   USB / DPS-TIS2WEB
        │ HTTPS/OMA-DM                                                │
   Telematics (CGM/EOCM)  ── cellular download conduit ──┐            │
        │ internal Ethernet                              ▼            ▼
   gmConnectionService → Binder IPC →      gm_update_engine  (root, block-device write)
                                                 │  exec()
                                          Red Bend UA (rb_ua)  → Android/GHS partition writes
                                                 │  UDS over IPC
                                          VIP MCU (RH850)  → UDS ($10/$27/$34/$36/$37/$31/$11)
                                                 │            over CAN / IPC
                                          radio sub-modules (VIP_APP/BOOT, HostOS, ABL, TUNER,
                                                             ETH_SWITCH, GPS, SXM)
```

- **SecureUnlock** = UDS SecurityAccess ($27); the CSM program log
  ([`../diagnostics/dps/A11_CSM.ProgramLog.Txt`](../diagnostics/dps/A11_CSM.ProgramLog.Txt))
  drives it, the **VIP enforces** it (PROTOKEY / MEC / SBAT on the VIP); GM backend supplies the key.
- The Android update stack (`gm_update_engine`, `rb_ua`, `libpal_swupdate_ecu.so`, `IECUUpdate`
  HAL, the GHS `OTA_InitialTask` + `/dev/ghs/ota-isys`) all live **on the radio**.
- Radio's CAN reach is **only via the VIP**; the CGM/telematics has **direct** CAN.

## CalDef evidence for the orchestration role

From [`../reference/GIS-646_CalDef_Database_Info3.7_and_Info3.8_V7.0.8_19April2023/caldefs/`](../reference/):

- **GIS-658 `InfotainmentProgMaster_GlobalA`** — infotainment as **"Programming Master"** over
  GMLAN: `DEREGISTER_DURATION` ("Master waits for other Networked Devices"), `WAITING_ON_GMLAN`,
  `WAITING_ON_CLIENT` ("client reset to go to boot mode"), `NO_SWITCH_PROG_MODE`,
  `PROGRAMMING_ENABLED`, signing cert. Other ECUs are "clients" it enables into programming mode
  and feeds files. [C]
- **GIS-763 `InfotainmentProg_GlobalB`** — "Infotainment self programming." Holds
  **`GIS763_Gateway` = 69 (0x45)** = "Diagnostic Address of the CGM"; SecurityAccess timers
  (`WAITING_FOR_SECURE_ACCESS`, `WAITING_ON_SESSION_KEYS`, `WAITING_FOR_SEED`),
  `WAITING_FOR_PROGRAMMING_SUPPORT`, `WAITING_FOR_ECUS_TO_WAKE`. Historical pared-down
  `Immobilizer1/2_Address` cals show per-ECU targeting existed. The infotainment addresses the
  **gateway** and does the seed/key unlock. [C]
- **GIS-887 `RemoteProgrammingHMI_GlobalB`** (OTA GB **Phase 2**) — introduces the **RRM (Remote
  Reflash Master)** + infotainment state **`RemoteReflashProgramming`**; infotainment (UIM)
  monitors the **RRM's FSA heartbeat** and is the **HMI/consent/scheduling/status** surface, with
  `DU_Progress = RunningInternal|RunningExternal` (flashing the infotainment itself vs external
  modules). Heavy lifting moves to an RRM/FSA actor; infotainment demoted to HMI. [C]
- **GIS-797 / GIS-787** — OTA update-check cadence + reflash-completion display timer (HMI only).
  `GIS768_Remote_Reflash_Feature = TRUE` + `IgnoreCurrentPartNumberCheck = TRUE` are the enabling
  flags. [C]

**Reading:** the orchestrator moves **infotainment Programming Master (Global A) → infotainment
self-programming addressing gateway 0x45 (Global B Phase 1) → RRM/FSA with infotainment as HMI
(Global B Phase 2)**. The FSA `ProgrammingMaster` service on the radio (`.100:9011`) and
`RemoteReflash`/`RemoteReflashUI` on other nodes match the Phase-2 RRM model.

> **[P] CORRECTION (2026-09):** live RE + a live port scan confirm the FSA `ProgrammingMaster`
> catalog entry (`.100:9011`, serviceId 1006) is **dead code on this build** — compiled into the
> CSM image but never instantiated; port 9011 is never bound (only 9002/9010/9016 LISTEN). This is
> consistent with, and reinforces, the Phase-2 reading above: Global-B fully demoted infotainment
> from Programming Master to an RRM/FSA HMI role, to the point the old Programming Master service
> class ships unused. See [`fsa_protocol.md`](fsa_protocol.md#p-programmingmaster-9011-is-dead-code).

> **[U] No network→install path (2026-09).** `RemoteReflash` (FSA `9012`) has Android as a
> **client** dialing `.102` (telematics), not a server; inbound events dispatch to
> `IRemoteReflashServiceEvents`, which is **unsubscribed system-wide** (verified across 6 apps
> incl. `CriticalWKSApp`/`GMTCPS`). Combined with `UpdateServiceImplGB.install()` being reachable
> only via local Binder (no network path), there is no confirmed unauthenticated-Ethernet-peer path
> to triggering a reflash on this build. `.102` is IP-pinned with no TLS pinning; L2/L3 spoofing of
> `.102` is a bench open item. Rollback is separately **hardware-enforced** — GHS keeps its own
> misc-partition rollback counter independent of AVB, un-influenceable from any network surface
> documented here. See
> [`../research/AE_RESEARCH_HANDOFF.md`](../research/AE_RESEARCH_HANDOFF.md#update--rollback--influence-verdicts-network-peer-over-ethernet-resolved-2026-09)
> and [`ota_update_stack.md`](ota_update_stack.md).

> **[U] INSTALLRUNNER trace (2026-09) — refines the local-Binder gap, doesn't reopen it.**
> `UpdateServiceImplGB.install()`'s missing permission check is reachable only from
> **priv_app/platform_app/carservice_app** (SELinux `gm_domain_service` `find` grant), not
> untrusted_app/shell — and even from there, the caller's IPC `PackageDetails` argument is never
> consumed by the install pipeline (`retrievePackageFromMessage()` only accepts an internal
> `Package` object); `InstallRunner.install(pkg)` always uses the vehicle's own legitimately-staged
> package. Net effect of exploiting the missing check: forced/premature triggering of an
> already-staged update (consent-bypass/DoS), **not** attacker-content substitution. One open item —
> `DevCaloverrideInstaller` (containerType 2) skips signature verification entirely, but its only
> trigger (`USBUpdateSource$1.onUSBMounted`) requires physical USB media and is not IPC-reachable;
> Y175's installed `USBNotifier` was examined on 2026-10-30: it selects type 2
> only on non-`user` builds, and the tested Y175 is a `user` build. Y181's
> notifier and alternate entry points remain to be independently verified. Full trace:
> [`ota_update_stack.md`](ota_update_stack.md) and
> [`../research/security/AAOS_OFFENSIVE_AUDIT_PHASE1_SEP2026.md`](../research/security/AAOS_OFFENSIVE_AUDIT_PHASE1_SEP2026.md).

## GM dealer service programming (SPS2) — official procedure

From GM service data (ALLDATA *Control Module References → Programming and Setup*), the
dealer-side reflash path for the modules this radio orchestrates:

- **A11 Radio — USB-mediated SPS, not a straight bus push.** SPS2 generates the payload, then it
  is **copied to a USB stick** ("USB File Transfer") and installed by the infotainment itself:
  requires an **EL-52100 MDI 2** (the older EL-47955 MDI **fails**), USB **FAT32 ≥16 GB** (USB
  3.x recommended), vehicle OFF/PARK/door-closed, stable voltage via a *maintainer*. Flow: SPS →
  *A11 Radio – Programming* → USB copy → move to vehicle → ignition/infotainment ON → on-screen
  "Update" → Clear DTCs → **reset the Manufacturer Enable Counter (MEC) via GDS2** → ignition OFF,
  RAP off, fob removed, 5-min wait. (Check *Settings → Updates* for a pending OTA first.)
  Failed-programming recovery = de-power the module ≥10 min (fuse/connector/battery) then retry.
- **T3 Audio Amplifier — standard SPS**, no USB, no MEC: ignition OFF → SPS *T3 – Programming* →
  Clear DTCs.
- **MDI 2 relevance:** this is the same dealer tool family the repo's `mdi2_client/` speaks to —
  the USB-SPS/MEC detail explains why the radio's reflash path differs from a plain UDS `$34/$36`
  push and why MEC state matters after programming.

This is the **dealer** path; it is orthogonal to the GHS/`gm_update_engine` OTA machinery
documented above (which is how GM pushes signed packages OTA/USB to the running stack).

## Global B provisioning & SPS/DPS economics — external corroboration [X]

> **Source.** Snipesy / Surreal Development, *"The ABCs of Global B"*, 2026-06-16, **CC0 1.0**
> (`https://surrealdev.com/the-abcs-of-global-b/`; canonical bibliography:
> [`qualcomm_cadillac_platform.md`](qualcomm_cadillac_platform.md) → Sources). Independent public
> RE, primary vehicles a 2023 Chevy Colorado (Intel) and 2025
> Cadillac Lyriq/CT5 (Qualcomm SA8155P). **[X]** = external/other-vehicle, not independently
> confirmed on this A11 unit; corroborates the reconciled model above but read the caveats.

- **Global B lineage.** GM's newer architecture (author says previously branded **Ultifi** / "VIP
  Architecture"), standard across the GM lineup **since 2023**, replacing Global A. Note this repo
  treats **Ultifi** as the GM *Android service layer* (`com.gm.ultifi.*`), so treat "Global B =
  Ultifi" as the author's naming, not a confirmed equivalence here. [X]
- **Circle of accountability.** Every significant module (30+ on some vehicles) handshakes the
  central gateway at start using a factory-provisioned secret; one failure → whole-vehicle **no
  start** + DTC **U1962**. Proper module replacement requires GM's **Serial Data Authentication
  Configuration (SDAC)** run against GM's **"back office"** (Azure-hosted for NA), which holds the
  CA/private keys — the vehicle cannot self-provision. [X]
  - *Caveat / naming conflict:* the author uses **SDGM = SGM = CGM = "central gateway"**
    interchangeably. **Do not adopt that equation here** — this research has (a) *not* established
    CAN gateway `0x45` as the CGM (see [`vehicle_network.md`](vehicle_network.md) Join-points item
    #3; `/Volumes/.../VEHICLE_NETWORK_TOPOLOGY.md`), and (b) uses **SGM = Shanghai-GM** (SAIC-GM
    regional key backend, `tisvcsv4.dll`), a false-friend collision. "SDGM" is the author's term.
- **$27 SecurityAccess.** Author states $27 is taken **against the SDGM/central gateway** (not the
  target module, unlike Global A), seed changes per request, tester must round-trip GM's servers
  (SPS2/3) for the key; **secondary $27 blockers** (notably key reprogramming) use a *different*
  server-side key, so gateway access ≠ whole-vehicle access. *Caveat:* on **this** platform the DPS
  captures show $27 as a **per-ECU** exchange (seed/key direct to ECU `0x80` radio, `0x45` gateway
  — `LIVE_DPS_CAPTURE_ECU80_AUG2026.md`), so the "always against the SDGM" framing is Cadillac-
  specific / unconfirmed here. The per-VIN SPS-events cap and secondary-key detail are additive. [X]
- **SPS/DPS economics & bypass.** SPS3 ≈ **$4,400/yr** or **$45** temporary single-VIN license;
  gives an SPS3 credential usable to obtain $27. **DPS** provisions $27 just-in-time for suppliers
  (privileged actions incl. key reprogramming, but not arbitrary-image install). Author: it is
  "trivial" to **spoof the SPS3/DPS flow** (pretend to be the vehicle) or **hijack a live SPS
  session** to grab the $27 key; GM has **rate-limited SPS events per VIN** to hamper tuners. [X]
- **GM cloud/OTA auth composition.** The head-unit's GM-server auth is built from **3 configurable
  values — gateway/CGM id + radio/CSM id + VIN** (~40 bytes entropy) — plus baked-in hardcoded
  values and an **obfuscated OAuth2 secret shared per Android build** (author notes the OAuth2
  secret is low-value; the 3 config values are the real secret). A signed cert derived from these
  is then used for all subsequent API calls; the **telematics module performs the actual OTA
  download**, radio only kicks off the campaign. Aligns with the Cloud→CGM→`gmConnectionService`→
  `gm_update_engine` chain above; the 3-value+OAuth2 composition is new/additive. [X]

## Verification plan

Capture **CAN + VIP↔SoC HDLC IPC + FSA** simultaneously during a real multi-module OTA:
- Foreign-module `$34/$36/$37` transfers originating from the radio (via VIP → CAN → gateway
  `0x45`) ⇒ radio/VIP is the agent for foreign ECUs too.
- Transfers dispatched over FSA to a CGM/RRM that executes them on its direct CAN ⇒ radio is
  coordinator/HMI only and hands execution off.

Current evidence supports **radio-VIP for radio-domain modules**; **foreign-module execution is
unproven** (defined in CalDefs, not captured). Highest-value capture for closing the OTA question.
